// src/pages/Dashboard/Dashboard.jsx
import { useState, useEffect } from 'react';
import { Box, Container } from '@mui/material';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import WelcomeSection from './components/WelcomeSection';
import StatsCards from './components/StatsCards';
import LearningProgress from './components/LearningProgress';
// import RecommendedPeers from './components/RecommendedPeers';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetch user data from localStorage or API
    const fetchUser = async () => {
      try {
        // Check if user is stored in localStorage
        const storedUser = localStorage.getItem('user');
        
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        } else {
          // If not in localStorage, you might want to fetch from API
          // const response = await fetch('http://localhost:8000/api/auth/user', {
          //   headers: {
          //     'Authorization': `Bearer ${localStorage.getItem('token')}`
          //   }
          // });
          // const userData = await response.json();
          // setUser(userData);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  // Mock data for the dashboard
  const statsData = {
    studyStreak: 14,
    activeGroups: 5,
    earnedBadges: 16
  };

  if (isLoading) {
    return <div>Loading...</div>; // You can replace with a proper loading component
  }

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f5f7fa' }}>
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main content */}
      <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
        {/* Header */}
        <Header user={user} />
        
        {/* Main dashboard content */}
        <Container maxWidth="xl" sx={{ py: 3 }}>
          {/* Welcome section */}
          <WelcomeSection user={user} />
          
          {/* Stats cards */}
          <StatsCards data={statsData} />
          
          {/* Charts and recommendations section */}
          <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, mt: 4, gap: 3 }}>
            <Box sx={{ flex: 2 }}>
              <LearningProgress />
            </Box>
            <Box sx={{ flex: 1 }}>
              {/* <RecommendedPeers /> */}
            </Box>
          </Box>
        </Container>
      </Box>
    </Box>
  );
};

export default Dashboard;