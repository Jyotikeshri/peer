// src/pages/Dashboard/components/StatsCards.jsx
import { Box, Grid, Paper, Typography } from '@mui/material';
import {
  LocalFireDepartment as FireIcon,
  Group as GroupIcon,
  EmojiEvents as BadgeIcon,
  CheckCircle as CheckIcon,
  Link as LinkIcon,
  Warning as WarningIcon
} from '@mui/icons-material';

const StatCard = ({ title, value, icon, color, bgColor }) => {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 2,
        backgroundColor: bgColor,
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box>
          <Typography variant="body2" sx={{ mb: 1, color: 'text.secondary', fontWeight: 'medium' }}>
            {title}
          </Typography>
          <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'text.primary' }}>
            {value}
          </Typography>
        </Box>
        <Box
          sx={{
            width: 40,
            height: 40,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: `${color}20`,
            color: color
          }}
        >
          {icon}
        </Box>
      </Box>
    </Paper>
  );
};

const StatsCards = ({ data }) => {
  const { studyStreak, activeGroups, earnedBadges } = data;

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={4}>
        <StatCard
          title="Study Streak"
          value={`${studyStreak} days`}
          icon={<CheckIcon />}
          color="#4CAF50"
          bgColor="#e8f5e9"
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <StatCard
          title="Study Groups"
          value={`${activeGroups} active`}
          icon={<LinkIcon />}
          color="#2196F3"
          bgColor="#e3f2fd"
        />
      </Grid>
      <Grid item xs={12} md={4}>
        <StatCard
          title="Earned Badges"
          value={`${earnedBadges} total`}
          icon={<WarningIcon />}
          color="#F44336"
          bgColor="#ffebee"
        />
      </Grid>
    </Grid>
  );
};

export default StatsCards;