import { useState } from 'react';
import { 
  Box, 
  Typography, 
  Avatar, 
  IconButton, 
  Menu, 
  MenuItem,
  useTheme,
  Link,
  Grid
} from '@mui/material';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import ImageIcon from '@mui/icons-material/Image';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import { formatDistanceToNow } from 'date-fns';
import useMessageStore from '../../../contexts/messageStore';

const MessageBubble = ({ message, isOwn, showAvatar, showTime, currentUser, conversation }) => {
  const theme = useTheme();
  const [anchorEl, setAnchorEl] = useState(null);
  const { deleteMessage } = useMessageStore();
  
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleDeleteMessage = async () => {
    try {
      await deleteMessage(message._id, message.conversationId);
      handleMenuClose();
    } catch (error) {
      console.error('Error deleting message:', error);
    }
  };
  
  const formatMessageTime = (date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };
  
  const getSenderName = () => {
    if (isOwn) return 'You';
    
    if (conversation?.isGroup) {
      return message.sender.name || 'Unknown User';
    }
    
    return null; // Don't show sender name for 1-on-1 chats
  };
  
  const getFileIcon = (url) => {
    const extension = url.split('.').pop().toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) {
      return <ImageIcon fontSize="small" />;
    } else if (extension === 'pdf') {
      return <PictureAsPdfIcon fontSize="small" />;
    } else {
      return <InsertDriveFileIcon fontSize="small" />;
    }
  };
  
  const getFileName = (url) => {
    // Extract filename from URL
    const parts = url.split('/');
    let filename = parts[parts.length - 1];
    
    // Remove any query parameters
    filename = filename.split('?')[0];
    
    // Decode URI components
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      // If decoding fails, use as is
    }
    
    return filename;
  };
  
  const isImageAttachment = (url) => {
    const extension = url.split('.').pop().toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif'].includes(extension);
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: isOwn ? 'row-reverse' : 'row',
        mb: 1,
        alignItems: 'flex-end'
      }}
    >
      {showAvatar && !isOwn ? (
        <Avatar 
          src={message.sender.avatar} 
          sx={{ width: 32, height: 32, mr: 1 }}
        >
          {message.sender.name?.charAt(0).toUpperCase()}
        </Avatar>
      ) : (
        <Box sx={{ width: 32, mr: 1 }} />
      )}
      
      <Box
        sx={{
          maxWidth: '70%',
          position: 'relative'
        }}
      >
        {/* Sender name for group chats */}
        {conversation?.isGroup && !isOwn && showAvatar && (
          <Typography 
            variant="caption" 
            color="text.secondary"
            sx={{ ml: 1, display: 'block', mb: 0.5 }}
          >
            {message.sender.name || 'Unknown User'}
          </Typography>
        )}
        
        {/* Message bubble */}
        <Box
          sx={{
            backgroundColor: isOwn 
              ? theme.palette.primary.main 
              : theme.palette.grey[100],
            color: isOwn 
              ? theme.palette.primary.contrastText 
              : theme.palette.text.primary,
            borderRadius: 2,
            p: 1.5,
            position: 'relative',
            boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
            wordBreak: 'break-word'
          }}
        >
          {message.isDeleted ? (
            <Typography 
              variant="body2" 
              sx={{ fontStyle: 'italic', opacity: 0.7 }}
            >
              This message was deleted
            </Typography>
          ) : (
            <>
              {/* Message text */}
              {message.text && (
                <Typography variant="body1" sx={{ mb: message.attachments?.length > 0 ? 2 : 0 }}>
                  {message.text}
                </Typography>
              )}
              
              {/* Attachments */}
              {message.attachments && message.attachments.length > 0 && (
                <Box sx={{ mt: message.text ? 1 : 0 }}>
                  <Grid container spacing={1}>
                    {message.attachments.map((attachment, index) => (
                      <Grid item xs={12} key={index}>
                        {isImageAttachment(attachment) ? (
                          // Image preview
                          <Box 
                            component="img"
                            src={attachment}
                            alt="Attachment"
                            sx={{ 
                              maxWidth: '100%', 
                              maxHeight: 200, 
                              borderRadius: 1,
                              cursor: 'pointer'
                            }}
                            onClick={() => window.open(attachment, '_blank')}
                          />
                        ) : (
                          // File link
                          <Link 
                            href={attachment} 
                            target="_blank" 
                            rel="noopener"
                            underline="hover"
                            sx={{ 
                              display: 'flex', 
                              alignItems: 'center',
                              color: isOwn ? 'inherit' : theme.palette.primary.main
                            }}
                          >
                            {getFileIcon(attachment)}
                            <Typography variant="body2" sx={{ ml: 1 }}>
                              {getFileName(attachment)}
                            </Typography>
                          </Link>
                        )}
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              )}
            </>
          )}
          
          {showTime && (
            <Typography 
              variant="caption" 
              sx={{ 
                position: 'absolute',
                bottom: -18,
                [isOwn ? 'right' : 'left']: 8,
                color: 'text.disabled',
                fontSize: '0.7rem'
              }}
            >
              {formatMessageTime(message.createdAt)}
            </Typography>
          )}
        </Box>
      </Box>
      
      {/* Message options */}
      {isOwn && !message.isDeleted && (
        <Box>
          <IconButton 
            size="small" 
            onClick={handleMenuOpen}
            sx={{
              opacity: anchorEl ? 1 : 0,
              '&:hover': { opacity: 1 },
              transition: 'opacity 0.2s',
              mx: 0.5
            }}
          >
            <MoreHorizIcon fontSize="small" />
          </IconButton>
          
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
          >
            <MenuItem onClick={handleDeleteMessage}>Delete</MenuItem>
          </Menu>
        </Box>
      )}
    </Box>
  );
};

export default MessageBubble;
          