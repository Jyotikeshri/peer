import { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  Typography, 
  Avatar, 
  IconButton, 
  TextField, 
  InputAdornment,
  CircularProgress,
  useTheme,
  Paper,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  List,
  ListItem,
  ListItemIcon,
  ListItemText
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SendIcon from '@mui/icons-material/Send';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import CloseIcon from '@mui/icons-material/Close';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import ImageIcon from '@mui/icons-material/Image';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import { formatDistanceToNow } from 'date-fns';
import useMessageStore from '../../../contexts/messageStore';
import useUserStore from '../../../contexts/userStore';
import { useSocket } from '../../../contexts/SocketContext';
import MessageBubble from './MessageBubble';

const MessageArea = ({ conversationId, setShowDetails, showDetailsButton, currentUser }) => {
  const theme = useTheme();
  const [message, setMessage] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [showAttachments, setShowAttachments] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  
  const { 
    conversations,
    messages,
    isLoading,
    fetchMessages,
    sendMessage,
    setActiveConversation,
    typingUsers
  } = useMessageStore();
  
  const { emitTyping } = useSocket();
  
  const conversation = conversations.find(c => c._id === conversationId);
  const conversationMessages = messages[conversationId] || [];
  const typingUsersInConversation = typingUsers[conversationId] || [];

  useEffect(() => {
    if (conversationId) {
      fetchMessages(conversationId);
    }
  }, [conversationId, fetchMessages]);

  useEffect(() => {
    scrollToBottom();
  }, [conversationMessages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleInputChange = (e) => {
    setMessage(e.target.value);
    
    // Emit typing event with debounce
    clearTimeout(typingTimeoutRef.current);
    emitTyping(conversationId);
  };

  const handleSendMessage = async () => {
    if (!message.trim() && attachments.length === 0) return;
    
    try {
      await sendMessage(conversationId, message, attachments.map(attachment => attachment.url));
      setMessage('');
      setAttachments([]);
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleAttachmentClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    
    setIsUploading(true);
    
    try {
      // Create FormData for file upload
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file);
      });
      
      // Upload files to server
      const response = await fetch('http://localhost:8000/api/messages/upload', {
        method: 'POST',
        credentials: 'include',
        body: formData
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload files');
      }
      
      const data = await response.json();
      
      // Add uploaded files to attachments
      setAttachments([...attachments, ...data.attachments]);
      
      // Reset file input
      e.target.value = '';
    } catch (error) {
      console.error('Error uploading files:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const getFileIcon = (fileType) => {
    if (fileType.startsWith('image/')) {
      return <ImageIcon />;
    } else if (fileType === 'application/pdf') {
      return <PictureAsPdfIcon />;
    } else {
      return <InsertDriveFileIcon />;
    }
  };

  const getConversationName = () => {
    if (!conversation) return 'Loading...';
    
    if (conversation.isGroup) {
      return conversation.groupName;
    }
    
    const otherUser = conversation.participants.find(p => p._id !== currentUser._id);
    return otherUser?.name || 'Unknown User';
  };

  const getConversationAvatar = () => {
    if (!conversation) return null;
    
    if (conversation.isGroup) {
      return null; // Use first letter of group name
    }
    
    const otherUser = conversation.participants.find(p => p._id !== currentUser._id);
    return otherUser?.avatar;
  };

  const getTypingIndicator = () => {
    if (typingUsersInConversation.length === 0) return null;
    
    // Get names of typing users
    const typingUserNames = typingUsersInConversation.map(userId => {
      const participant = conversation.participants.find(p => p._id === userId);
      return participant?.name || 'Someone';
    });
    
    if (typingUserNames.length === 1) {
      return `${typingUserNames[0]} is typing...`;
    } else if (typingUserNames.length === 2) {
      return `${typingUserNames[0]} and ${typingUserNames[1]} are typing...`;
    } else {
      return 'Several people are typing...';
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Conversation header */}
      <Box sx={{ 
        p: 2, 
        display: 'flex', 
        alignItems: 'center', 
        borderBottom: `1px solid ${theme.palette.divider}` 
      }}>
        <IconButton 
          sx={{ display: { xs: 'inline-flex', md: 'none' }, mr: 1 }}
          onClick={() => setActiveConversation(null)}
        >
          <ArrowBackIcon />
        </IconButton>
        
        <Avatar 
          src={getConversationAvatar()} 
          sx={{ width: 40, height: 40, mr: 2 }}
        >
          {getConversationName().charAt(0).toUpperCase()}
        </Avatar>
        
        <Box sx={{ flexGrow: 1 }}>
          <Typography variant="subtitle1" fontWeight="medium">
            {getConversationName()}
          </Typography>
          {typingUsersInConversation.length > 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>
              {getTypingIndicator()}
            </Typography>
          )}
        </Box>
        
        {showDetailsButton && (
          <IconButton onClick={setShowDetails}>
            <MoreVertIcon />
          </IconButton>
        )}
      </Box>
      
      {/* Messages area */}
      <Box sx={{ 
        flexGrow: 1, 
        overflow: 'auto', 
        p: 2, 
        display: 'flex',
        flexDirection: 'column'
      }}>
        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
            <CircularProgress size={40} />
          </Box>
        ) : conversationMessages.length > 0 ? (
          conversationMessages.map((msg, index) => (
            <MessageBubble
              key={msg._id}
              message={msg}
              isOwn={msg.sender._id === currentUser._id}
              showAvatar={
                index === 0 || 
                conversationMessages[index - 1].sender._id !== msg.sender._id
              }
              showTime={
                index === conversationMessages.length - 1 || 
                conversationMessages[index + 1].sender._id !== msg.sender._id
              }
              currentUser={currentUser}
              conversation={conversation}
            />
          ))
        ) : (
          <Box sx={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center',
            height: '100%'
          }}>
            <Typography color="text.secondary">
              No messages yet. Start the conversation!
            </Typography>
          </Box>
        )}
        <div ref={messagesEndRef} />
      </Box>
      
      {/* Attachment chips */}
      {attachments.length > 0 && (
        <Box sx={{ 
          p: 1, 
          backgroundColor: theme.palette.background.default,
          display: 'flex',
          flexWrap: 'wrap',
          gap: 1
        }}>
          {attachments.map((attachment, index) => (
            <Chip
              key={index}
              icon={getFileIcon(attachment.filetype)}
              label={attachment.filename}
              onDelete={() => handleRemoveAttachment(index)}
              variant="outlined"
              color="primary"
            />
          ))}
        </Box>
      )}
      
      {/* Input area */}
      <Paper
        elevation={3}
        sx={{
          p: 2,
          borderTop: `1px solid ${theme.palette.divider}`,
          backgroundColor: theme.palette.background.default
        }}
      >
        <TextField
          fullWidth
          multiline
          maxRows={4}
          placeholder="Type a message..."
          variant="outlined"
          value={message}
          onChange={handleInputChange}
          onKeyPress={handleKeyPress}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <IconButton
                  color="primary"
                  onClick={handleAttachmentClick}
                  edge="start"
                  disabled={isUploading}
                >
                  {isUploading ? <CircularProgress size={20} /> : <AttachFileIcon />}
                </IconButton>
                <input
                  type="file"
                  multiple
                  ref={fileInputRef}
                  style={{ display: 'none' }}
                  onChange={handleFileChange}
                />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  color="primary"
                  onClick={handleSendMessage}
                  disabled={(!message.trim() && attachments.length === 0) || isUploading}
                  edge="end"
                >
                  <SendIcon />
                </IconButton>
              </InputAdornment>
            )
          }}
        />
      </Paper>
      
      {/* Attachments Dialog */}
      <Dialog open={showAttachments} onClose={() => setShowAttachments(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Attachments</DialogTitle>
        <DialogContent>
          <List>
            {attachments.map((attachment, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  {getFileIcon(attachment.filetype)}
                </ListItemIcon>
                <ListItemText 
                  primary={attachment.filename} 
                  secondary={attachment.filetype}
                />
                <IconButton onClick={() => handleRemoveAttachment(index)}>
                  <CloseIcon />
                </IconButton>
              </ListItem>
            ))}
          </List>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowAttachments(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default MessageArea;
