// src/pages/Messages/components/NoConversationSelected.jsx
import { Box, Typography, Button } from '@mui/material';
import ChatIcon from '@mui/icons-material/Chat';
import { useNavigate } from 'react-router-dom';

const NoConversationSelected = () => {
  const navigate = useNavigate();

  return (
    <Box 
      sx={{ 
        display: 'flex', 
        flexDirection: 'column', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100%',
        p: 3
      }}
    >
      <ChatIcon sx={{ fontSize: 80, color: 'text.disabled', mb: 2 }} />
      
      <Typography variant="h5" gutterBottom>
        Select a conversation
      </Typography>
      
      <Typography color="text.secondary" align="center" sx={{ mb: 3, maxWidth: 400 }}>
        Choose an existing conversation from the list or start a new one to begin messaging
      </Typography>
      
      <Button 
        variant="contained" 
        color="primary"
        onClick={() => navigate('/dashboard')}
      >
        Find Peers
      </Button>
    </Box>
  );
};

export default NoConversationSelected;