import { useState } from 'react';
import { 
  Box, 
  Typography, 
  List, 
  ListItem, 
  ListItemAvatar, 
  Avatar, 
  ListItemText, 
  Divider, 
  TextField, 
  InputAdornment, 
  IconButton,
  Badge,
  Fab,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  CircularProgress,
  useTheme
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import { formatDistanceToNow } from 'date-fns';
import useMessageStore from '../../../contexts/messageStore';
import useUserStore from '../../../contexts/userStore';

const ConversationList = ({ conversations, activeConversation, setActiveConversation, currentUser }) => {
  const theme = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const { createGroupConversation, createConversation } = useMessageStore();
  const { fetchUser } = useUserStore();

  // Filter conversations based on search query
  const filteredConversations = conversations.filter(conv => {
    // For one-on-one conversations, filter by other user's name
    if (!conv.isGroup) {
      const otherUser = conv.participants.find(p => p._id !== currentUser._id);
      return otherUser?.name?.toLowerCase().includes(searchQuery.toLowerCase());
    }
    // For group conversations, filter by group name
    return conv.groupName?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleSearchUsers = async (query) => {
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    try {
      const response = await fetch(`http://localhost:8000/api/users/search?q=${query}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to search users');
      }
      
      const data = await response.json();
      setSearchResults(data.filter(user => user._id !== currentUser._id));
    } catch (error) {
      console.error('Error searching users:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddUser = (user) => {
    if (!selectedUsers.some(u => u._id === user._id)) {
      setSelectedUsers([...selectedUsers, user]);
    }
  };

  const handleRemoveUser = (userId) => {
    setSelectedUsers(selectedUsers.filter(user => user._id !== userId));
  };
  
  const handleCreateGroup = async () => {
    if (!groupName.trim() || selectedUsers.length === 0) {
      return;
    }
    
    try {
      const userIds = selectedUsers.map(user => user._id);
      await createGroupConversation(groupName, userIds);
      
      // Reset form
      setGroupName('');
      setSelectedUsers([]);
      setIsCreatingGroup(false);
    } catch (error) {
      console.error('Error creating group:', error);
    }
  };
  
  const handleStartConversation = async (userId) => {
    try {
      await createConversation(userId);
    } catch (error) {
      console.error('Error starting conversation:', error);
    }
  };
  
  const getConversationName = (conversation) => {
    if (conversation.isGroup) {
      return conversation.groupName;
    }
    
    const otherUser = conversation.participants.find(p => p._id !== currentUser._id);
    return otherUser?.name || 'Unknown User';
  };
  
  const getConversationAvatar = (conversation) => {
    if (conversation.isGroup) {
      return null; // Use first letter of group name
    }
    
    const otherUser = conversation.participants.find(p => p._id !== currentUser._id);
    return otherUser?.avatar;
  };
  
  const getLastMessage = (conversation) => {
    if (!conversation.lastMessage) {
      return 'No messages yet';
    }
    
    if (conversation.lastMessage.isDeleted) {
      return 'This message was deleted';
    }
    
    return conversation.lastMessage.text;
  };
  
  const getLastMessageTime = (conversation) => {
    if (!conversation.lastMessage?.createdAt) {
      return '';
    }
    
    return formatDistanceToNow(new Date(conversation.lastMessage.createdAt), { addSuffix: true });
  };
  
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Box sx={{ p: 2, borderBottom: `1px solid ${theme.palette.divider}` }}>
        <Typography variant="h6" fontWeight="bold" sx={{ mb: 2 }}>
          Messages
        </Typography>
        
        <TextField
          fullWidth
          placeholder="Search conversations..."
          variant="outlined"
          size="small"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>
      
      {/* Conversations list */}
      <List sx={{ 
        flexGrow: 1, 
        overflow: 'auto',
        p: 0 
      }}>
        {filteredConversations.length > 0 ? (
          filteredConversations.map((conversation) => (
            <Box key={conversation._id}>
              <ListItem 
                button
                selected={activeConversation === conversation._id}
                onClick={() => setActiveConversation(conversation._id)}
                sx={{ 
                  px: 2, 
                  py: 1.5,
                  backgroundColor: activeConversation === conversation._id ? 
                    `${theme.palette.primary.main}10` : 'transparent',
                  '&:hover': {
                    backgroundColor: `${theme.palette.primary.main}08`
                  }
                }}
              >
                <ListItemAvatar>
                  <Badge
                    color="error"
                    badgeContent={conversation.unreadCount || 0}
                    overlap="circular"
                    invisible={!conversation.unreadCount}
                  >
                    <Avatar src={getConversationAvatar(conversation)}>
                      {getConversationName(conversation).charAt(0).toUpperCase()}
                    </Avatar>
                  </Badge>
                </ListItemAvatar>
                <ListItemText 
                  primary={
                    <Typography
                      variant="subtitle1"
                      noWrap
                      sx={{ 
                        fontWeight: conversation.unreadCount ? 'bold' : 'normal',
                        color: conversation.unreadCount ? 'text.primary' : 'text.secondary'
                      }}
                    >
                      {getConversationName(conversation)}
                    </Typography>
                  }
                  secondary={
                    <Typography 
                      variant="body2" 
                      noWrap 
                      color="textSecondary"
                      sx={{ 
                        fontWeight: conversation.unreadCount ? 'medium' : 'normal',
                        color: conversation.unreadCount ? 'text.secondary' : 'text.disabled',
                        display: 'flex', 
                        justifyContent: 'space-between' 
                      }}
                    >
                      <span>{getLastMessage(conversation)}</span>
                      <span style={{ flexShrink: 0, marginLeft: '8px' }}>
                        {getLastMessageTime(conversation)}
                      </span>
                    </Typography>
                  }
                  primaryTypographyProps={{ noWrap: true }}
                  secondaryTypographyProps={{ noWrap: true }}
                />
              </ListItem>
              <Divider component="li" />
            </Box>
          ))
        ) : (
          <Box sx={{ p: 2, textAlign: 'center' }}>
            <Typography color="textSecondary">
              No conversations found
            </Typography>
          </Box>
        )}
      </List>
      
      {/* Create new conversation button */}
      <Box sx={{ p: 2 }}>
        <Tooltip title="New conversation">
          <Fab 
            color="primary" 
            size="medium" 
            onClick={() => setIsCreatingGroup(true)}
            sx={{ position: 'absolute', bottom: 20, right: 20 }}
          >
            <AddIcon />
          </Fab>
        </Tooltip>
      </Box>
      
      {/* Create group dialog */}
      <Dialog open={isCreatingGroup} onClose={() => setIsCreatingGroup(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create new conversation</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Group Name (optional)"
            fullWidth
            variant="outlined"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            sx={{ mb: 2 }}
          />
          
          <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Add participants:
          </Typography>
          
          <TextField
            fullWidth
            placeholder="Search users..."
            variant="outlined"
            size="small"
            onChange={(e) => handleSearchUsers(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
              endAdornment: isSearching ? (
                <InputAdornment position="end">
                  <CircularProgress size={20} />
                </InputAdornment>
              ) : null
            }}
          />
          
          {/* Search results */}
          <List dense>
            {searchResults.map((user) => (
              <ListItem 
                key={user._id}
                button
                onClick={() => handleAddUser(user)}
                disabled={selectedUsers.some(u => u._id === user._id)}
              >
                <ListItemAvatar>
                  <Avatar src={user.avatar}>
                    {user.name.charAt(0).toUpperCase()}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText 
                  primary={user.name}
                  secondary={user.username || user.email}
                />
              </ListItem>
            ))}
          </List>
          
          {/* Selected users */}
          {selectedUsers.length > 0 && (
            <>
              <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>
                Selected ({selectedUsers.length}):
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {selectedUsers.map((user) => (
                  <Chip
                    key={user._id}
                    avatar={<Avatar src={user.avatar}>{user.name.charAt(0).toUpperCase()}</Avatar>}
                    label={user.name}
                    onDelete={() => handleRemoveUser(user._id)}
                  />
                ))}
              </Box>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsCreatingGroup(false)}>Cancel</Button>
          <Button 
            onClick={handleCreateGroup} 
            variant="contained" 
            disabled={selectedUsers.length === 0}
          >
            {selectedUsers.length === 1 ? 'Start Chat' : 'Create Group'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
  };
  
  export default ConversationList;