import { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  IconButton, 
  Avatar, 
  List, 
  ListItem, 
  ListItemAvatar, 
  ListItemText,
  Divider,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  useTheme
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import useMessageStore from '../../../contexts/messageStore';
import useUserStore from '../../../contexts/userStore';

const ConversationDetails = ({ conversationId, onClose }) => {
  const theme = useTheme();
  const { conversations } = useMessageStore();
  const { user } = useUserStore();
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  
  const conversation = conversations.find(c => c._id === conversationId);
  
  const isGroupConversation = conversation?.isGroup;
  const isGroupAdmin = isGroupConversation && conversation?.groupAdmin === user?._id;
  
  const participants = conversation?.participants || [];
  
  const handleSearchUsers = async (query) => {
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }
    
    try {
      const response = await fetch(`http://localhost:8000/api/users/search?q=${query}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to search users');
      }
      
      const data = await response.json();
      
      // Filter out users who are already in the conversation
      const filteredResults = data.filter(
        user => !participants.some(p => p._id === user._id)
      );
      
      setSearchResults(filteredResults);
    } catch (error) {
      console.error('Error searching users:', error);
    }
  };
  
  const handleAddMember = async (userId) => {
    try {
      // API call to add member
      const response = await fetch(`http://localhost:8000/api/conversations/${conversationId}/members`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ userId })
      });
      
      if (!response.ok) {
        throw new Error('Failed to add member');
      }
      
      // Close dialog and refresh conversation
      setIsAddingMember(false);
      // TODO: Refresh conversation details
    } catch (error) {
      console.error('Error adding member:', error);
    }
  };
  
  const handleLeaveGroup = async () => {
    try {
      // API call to leave group
      const response = await fetch(`http://localhost:8000/api/conversations/${conversationId}/leave`, {
        method: 'PUT',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to leave group');
      }
      
      // Close details panel and maybe redirect
      onClose();
      // TODO: Handle redirect or refresh conversation list
    } catch (error) {
      console.error('Error leaving group:', error);
    }
  };
  
  if (!conversation) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography>Loading conversation details...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Box sx={{ 
        p: 2, 
        display: 'flex', 
        alignItems: 'center', 
        borderBottom: `1px solid ${theme.palette.divider}` 
      }}>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          Conversation Info
        </Typography>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </Box>
      
      {/* Content */}
      <Box sx={{ flexGrow: 1, overflow: 'auto', p: 2 }}>
        {/* Conversation avatar and name */}
        <Box sx={{ textAlign: 'center', mb: 3 }}>
          <Avatar
            sx={{ 
              width: 80, 
              height: 80, 
              mx: 'auto', 
              mb: 2,
              bgcolor: isGroupConversation ? 'primary.main' : undefined
            }}
            src={!isGroupConversation ? participants.find(p => p._id !== user?._id)?.avatar : undefined}
          >
            {isGroupConversation 
              ? conversation.groupName?.charAt(0).toUpperCase() 
              : participants.find(p => p._id !== user?._id)?.name?.charAt(0).toUpperCase()}
          </Avatar>
          
          <Typography variant="h6">
            {isGroupConversation 
              ? conversation.groupName 
              : participants.find(p => p._id !== user?._id)?.name || 'Unknown User'}
          </Typography>
          
          {isGroupConversation && (
            <Typography variant="body2" color="text.secondary">
              {participants.length} members
            </Typography>
          )}
        </Box>
        
        {/* Participants */}
        <Typography variant="subtitle1" fontWeight="medium" sx={{ mb: 1 }}>
          {isGroupConversation ? 'Members' : 'Participant'}
        </Typography>
        
        <List disablePadding>
          {participants.map((participant) => (
            <ListItem key={participant._id} sx={{ px: 0 }}>
              <ListItemAvatar>
                <Avatar src={participant.avatar}>
                  {participant.name?.charAt(0).toUpperCase()}
                </Avatar>
              </ListItemAvatar>
              <ListItemText 
                primary={participant.name || 'Unknown User'} 
                secondary={
                  participant._id === user?._id 
                    ? 'You' 
                    : (participant._id === conversation?.groupAdmin && isGroupConversation)
                      ? 'Admin'
                      : null
                }
              />
            </ListItem>
          ))}
        </List>
        
        {/* Add member button (for group admin) */}
        {isGroupConversation && isGroupAdmin && (
          <Button 
            startIcon={<AddIcon />}
            onClick={() => setIsAddingMember(true)}
            sx={{ mt: 2 }}
            fullWidth
            variant="outlined"
          >
            Add Members
          </Button>
        )}
        
        {/* Leave group button */}
        {isGroupConversation && (
          <Button 
            startIcon={<ExitToAppIcon />}
            onClick={handleLeaveGroup}
            sx={{ mt: 2 }}
            fullWidth
            color="error"
            variant="outlined"
          >
            Leave Group
          </Button>
        )}
      </Box>
      
      {/* Add member dialog */}
      <Dialog open={isAddingMember} onClose={() => setIsAddingMember(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add new members</DialogTitle>
        <DialogContent>
          <TextField
             autoFocus
             margin="dense"
             label="Search users"
             fullWidth
             variant="outlined"
             value={searchQuery}
             onChange={(e) => {
               setSearchQuery(e.target.value);
               handleSearchUsers(e.target.value);
             }}
           />
           
           <List sx={{ mt: 2 }}>
             {searchResults.length > 0 ? (
               searchResults.map((user) => (
                 <ListItem 
                   key={user._id}
                   button
                   onClick={() => handleAddMember(user._id)}
                 >
                   <ListItemAvatar>
                     <Avatar src={user.avatar}>
                       {user.name?.charAt(0).toUpperCase()}
                     </Avatar>
                   </ListItemAvatar>
                   <ListItemText 
                     primary={user.name} 
                     secondary={user.username || user.email} 
                   />
                 </ListItem>
               ))
             ) : (
               <ListItem>
                 <ListItemText 
                   primary={
                     searchQuery.length < 2 
                       ? "Type at least 2 characters to search" 
                       : "No users found"
                   }
                   primaryTypographyProps={{ color: "text.secondary", textAlign: "center" }}
                 />
               </ListItem>
             )}
           </List>
         </DialogContent>
         <DialogActions>
           <Button onClick={() => setIsAddingMember(false)}>Cancel</Button>
         </DialogActions>
       </Dialog>
     </Box>
   );
 };
 
 export default ConversationDetails;
 