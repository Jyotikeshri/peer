// src/pages/Messages/MessagesPage.jsx
import { useEffect, useState } from 'react';
import { Box, Container, Typography, CircularProgress, useTheme } from '@mui/material';
import Sidebar from '../Dashboard/components/Sidebar';
import Header from '../Dashboard/components/Header';
import ConversationList from './components/ConversationList';
import MessageArea from './components/MessageArea';
import ConversationDetails from './components/ConversationDetails';
import useUserStore from '../../contexts/userStore';
import useMessageStore from '../../contexts/messageStore';
import { useSocket } from '../../contexts/SocketContext';
import NoConversationSelected from './components/NoConversationSelected';

const MessagesPage = () => {
  const theme = useTheme();
  const { user, isLoading: userLoading } = useUserStore();
  const { 
    conversations, 
    activeConversation, 
    isLoading: messagesLoading,
    error, 
    fetchConversations,
    setActiveConversation 
  } = useMessageStore();
  const { joinConversation } = useSocket();
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    // Fetch conversations
    fetchConversations();
  }, [fetchConversations]);

  // Join conversation room when active conversation changes
  useEffect(() => {
    if (activeConversation) {
      joinConversation(activeConversation);
    }
  }, [activeConversation, joinConversation]);

  if (userLoading || messagesLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', color: 'error.main' }}>
        Error loading messages: {error}
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f5f7fa' }}>
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main content */}
      <Box sx={{ flexGrow: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {/* Header */}
        <Header />
        
        {/* Messages container */}
        <Container maxWidth="xl" sx={{ py: 2, flexGrow: 1, display: 'flex', overflow: 'hidden' }}>
          <Box sx={{ 
            display: 'flex', 
            width: '100%', 
            height: 'calc(100vh - 84px)', 
            borderRadius: 2, 
            overflow: 'hidden',
            bgcolor: 'background.paper',
            boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
          }}>
            {/* Conversations list */}
            <Box sx={{ 
              width: 320, 
              borderRight: `1px solid ${theme.palette.divider}`,
              display: { xs: activeConversation ? 'none' : 'block', md: 'block' }
            }}>
              <ConversationList 
                conversations={conversations} 
                activeConversation={activeConversation}
                setActiveConversation={setActiveConversation}
                currentUser={user}
              />
            </Box>
            
            {/* Message area */}
            <Box sx={{ 
              flexGrow: 1, 
              display: 'flex', 
              flexDirection: 'column',
              display: { xs: activeConversation ? 'flex' : 'none', md: 'flex' }
            }}>
              {activeConversation ? (
                <MessageArea 
                  conversationId={activeConversation}
                  setShowDetails={() => setShowDetails(!showDetails)}
                  showDetailsButton={true}
                  currentUser={user}
                />
              ) : (
                <NoConversationSelected />
              )}
            </Box>
            
            {/* Conversation details */}
            {showDetails && activeConversation && (
              <Box sx={{ 
                width: { xs: 280, md: 320 }, 
                borderLeft: `1px solid ${theme.palette.divider}`,
                display: { xs: showDetails ? 'block' : 'none', md: showDetails ? 'block' : 'none' }
              }}>
                <ConversationDetails 
                  conversationId={activeConversation}
                  onClose={() => setShowDetails(false)}
                />
              </Box>
            )}
          </Box>
        </Container>
      </Box>
    </Box>
  );
};

export default MessagesPage;